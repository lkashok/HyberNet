package com.demo.hibernate_CRUD;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration con = new Configuration().configure().addAnnotatedClass(Student.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();

		SessionFactory sf = con.buildSessionFactory(reg);

		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();

//		Student stu = new Student();
//		stu.setUid(101);
//		stu.setUname("boobal");
//		session.save(stu);
		
	List<Student> list = new ArrayList<Student>();
    list.add(new Student(102, "siva"));
    list.add(new Student(103, "gobal"));
    list.add(new Student(104, "ravi"));
    list.add(new Student(105, "giri"));

      for (Student stu : list) {
	    session.save(stu);

      }
      
      Student stu1 = (Student) session.get(Student.class, 102);
      System.out.println(stu1.getUid());
      System.out.println(stu1.getUname());
	
		Query query1 = session.createQuery("UPDATE Student set uname = :value1 WHERE uid = :value2");
		query1.setParameter("value1", "kaviyarasu");
		query1.setParameter("value2", 102);
		int resultList1 = query1.executeUpdate();
		
		Query query2 = session.createQuery("DELETE Student WHERE uid = :value2");
		query2.setParameter("value2", 102);
		int resultList2 = query2.executeUpdate();
		
		Query query3 = session.createQuery("FROM Student");
		List<Student> resultList3 = query3.list();
		
		for(Student st : resultList3)
		{
			System.out.println(st.getUid() + "\t" + st.getUname());
		}
		
		tx.commit();
		session.close();
		sf.close();
   
  
    	
    }
}
